export const MICROSOFT_VENDOR_ID = 0x045E;

export const MICROSOFT_PRODUCT_CLASSIC = 0x0823;
export const MICROSOFT_PRODUCT_PRO = 0x082A;

export const MICROSOFT_PRODUCTS: ReadonlySet<number> = new Set([
  MICROSOFT_PRODUCT_PRO,
  MICROSOFT_PRODUCT_CLASSIC,
]);

export const REPORT_ID_WRITE = 0x24;
export const REPORT_ID_READ = 0x27;

export const PROPERTY_DPI_WRITE = 0x96;
export const PROPERTY_DPI_READ = 0x97;

export const PROPERTY_COLOR_WRITE = 0xB2;
export const PROPERTY_COLOR_READ = 0xB3;

export const PROPERTY_POLLING_WRITE = 0x83;
export const PROPERTY_POLLING_READ = 0x84;

export const PROPERTY_DISTANCE_WRITE = 0xB8;
export const PROPERTY_DISTANCE_READ = 0xB6;

export const MICROSOFT_CLASSIC_USAGE_PAGE = 0x000C;
export const MICROSOFT_CLASSIC_USAGE = 0x0001;
export const MICROSOFT_PRO_USAGE_PAGE = 0xFF07;
export const MICROSOFT_PRO_USAGE = 0x0212;
