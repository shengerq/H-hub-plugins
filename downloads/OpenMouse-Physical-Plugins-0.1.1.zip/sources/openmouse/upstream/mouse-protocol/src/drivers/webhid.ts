export {};

declare global {
  interface HIDDeviceFilter {
    vendorId?: number;
    productId?: number;
    usagePage?: number;
    usage?: number;
  }
  
  interface HIDInputReportEvent extends Event {
    readonly device: HIDDevice;
    readonly reportId: number;
    readonly data: DataView;
  }
  
  interface HIDConnectionEvent extends Event {
    readonly device: HIDDevice;
  }
  
  interface HIDReportItem {
    readonly reportSize: number;
    readonly reportCount: number;
  }
  
  interface HIDReportInfo {
    readonly reportId: number;
    readonly items: readonly HIDReportItem[];
  }
  
  interface HIDCollectionInfo {
    readonly usagePage: number;
    readonly usage: number;
    readonly inputReports: readonly HIDReportInfo[];
    readonly outputReports: readonly HIDReportInfo[];
    readonly featureReports: readonly HIDReportInfo[];
    readonly children: readonly HIDCollectionInfo[];
  }
  
  interface HIDDevice {
    readonly vendorId: number;
    readonly productId: number;
    readonly productName: string;
    readonly opened: boolean;
    readonly collections: readonly HIDCollectionInfo[];
    open(): Promise<void>;
    close(): Promise<void>;
    sendReport(reportId: number, data: BufferSource): Promise<void>;
    sendFeatureReport(reportId: number, data: BufferSource): Promise<void>;
    receiveFeatureReport(reportId: number): Promise<DataView>;
    addEventListener(type: "inputreport", listener: (event: HIDInputReportEvent) => void): void;
    removeEventListener(type: "inputreport", listener: (event: HIDInputReportEvent) => void): void;
  }
  
  interface HID {
    getDevices(): Promise<HIDDevice[]>;
    requestDevice(options: { filters: HIDDeviceFilter[] }): Promise<HIDDevice[]>;
    addEventListener(
      type: "connect" | "disconnect",
      listener: (event: HIDConnectionEvent) => void,
      options?: boolean | AddEventListenerOptions,
    ): void;
    removeEventListener(
      type: "connect" | "disconnect",
      listener: (event: HIDConnectionEvent) => void,
      options?: boolean | EventListenerOptions,
    ): void;
  }
  
  interface Navigator {
    hid?: HID;
  }
}
