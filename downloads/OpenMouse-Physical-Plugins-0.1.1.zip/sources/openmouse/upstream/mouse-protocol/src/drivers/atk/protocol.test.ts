import assert from "node:assert/strict";
import test from "node:test";

import {
  ATK_BUTTON_CLASS,
  ATK_COMPX_COMMAND,
  ATK_COMPX_FIRMWARE_HEADER_LENGTH,
  ATK_COMPX_FIRMWARE_PAYLOAD_OFFSET,
  ATK_R1_BUTTONS,
  ATK_R1_MACRO_BASE,
  ATK_R1_MACRO_SLOT_COUNT,
  ATK_R1_MACRO_SLOT_LENGTH,
  ATK_R1_PROFILE_COUNT,
  ATK_R1_SHORTCUT_BASE,
  ATK_R1_SHORTCUT_SLOT_LENGTH,
  ATK_SENSORS,
  atkBuildReceiverPairRequest,
  atkBuildSetCurrentProfile,
  atkBuildDongleLight,
  atkDecodeAntiMistouch,
  atkCompxPayloadCrc,
  atkDecodeButtonAssignment,
  atkDecodeCurrentProfile,
  atkDecodeLiftOff,
  atkEncodeLiftOff,
  ATK_LIFT_OFF_MIN_CODE,
  ATK_LIFT_OFF_MAX_CODE,
  atkDecodePairingStatus,
  atkDecodeReceiverStatus,
  atkDecodeSensorMode,
  atkDpiOptionsForSensor,
  atkDpiStageLength,
  atkDecodeVxeR1PollingCode,
  atkPackDpiStage,
  atkPackDpiStageForSensor,
  atkPackAntiMistouch,
  atkPackSensorMode,
  atkPackVxeR1LiveSetting,
  atkPackVxeR1PollingSetting,
  atkParseCompxFirmware,
  atkUnpackDpiStage,
  atkUnpackDpiStageForSensor,
  ATK_VXE_R1_ANGLE_SELECTOR,
  ATK_VXE_R1_DEBOUNCE_SELECTOR,
  ATK_VXE_R1_LOD_SELECTOR,
  ATK_VXE_R1_POLLING_RATES,
} from "@openmouse/protocol/atk";
import { ATK_PRODUCTS } from "./products.ts";

test("DPI stages survive a round trip across every step range", () => {
  for (const [x, y] of [[50, 50], [800, 800], [10000, 1600], [10050, 10050], [26000, 26000], [42000, 42000]]) {
    const stage = atkPackDpiStage(x!, y!);
    const sum = stage.reduce((total, byte) => total + byte, 0);

    assert.equal(sum & 0xff, 0x55, `stage checksum for ${x}/${y}`);
    assert.deepEqual(atkUnpackDpiStage(stage), { x, y });
  }
});

test("DPI stages with a corrupt checksum are rejected", () => {
  const stage = atkPackDpiStage(1600, 1600);
  stage[3] ^= 0xff;

  assert.equal(atkUnpackDpiStage(stage), null);
  assert.equal(atkUnpackDpiStage([1, 2, 3]), null);
});

test("PAW3395SE decodes exact wired EEPROM captures", () => {
  const captures: ReadonlyArray<readonly [readonly number[], number]> = [
    [[0x12, 0x12, 0x00, 0x31], 800],
    [[0x25, 0x25, 0x00, 0x0b], 1600],
    [[0x4b, 0x4b, 0x00, 0xbf], 3200],
  ];
  for (const [stage, dpi] of captures) {
    assert.deepEqual(atkUnpackDpiStageForSensor("PAW3395SE", stage), { x: dpi, y: dpi });
    assert.deepEqual(atkPackDpiStageForSensor("PAW3395SE", dpi, dpi), stage);
  }
});

test("PAW3395SE uses independent doubled bits above 10000 DPI", () => {
  const stage = atkPackDpiStageForSensor("PAW3395SE", 10100, 18000);
  assert.ok(stage);
  assert.equal(stage[2], 0x22);
  assert.deepEqual(atkUnpackDpiStageForSensor("PAW3395SE", stage), { x: 10100, y: 18000 });

  const xOnly = atkPackDpiStageForSensor("PAW3395SE", 10100, 3200);
  const yOnly = atkPackDpiStageForSensor("PAW3395SE", 3200, 10100);
  assert.equal(xOnly?.[2], 0x02);
  assert.equal(yOnly?.[2], 0x20);
});

test("PAW3395SE rejects code holes and invalid doubled values", () => {
  const invalidCodes = [
    0, 7, 13, 20, 26, 33, 40, 46, 53, 60, 66, 73, 80, 86, 93, 100, 106,
    113, 120, 126, 133, 140, 146, 153, 160, 166, 173, 180, 186, 193, 200,
    206, 213, 220, 226, 233, 236, 255,
  ];
  for (const code of invalidCodes) {
    const checksum = (0x55 - code * 2) & 0xff;
    assert.equal(atkUnpackDpiStageForSensor("PAW3395SE", [code, code, 0, checksum]), null, `code ${code}`);
  }
  assert.equal(atkUnpackDpiStageForSensor("PAW3395SE", [0x12, 0x12, 0x22, 0x0f]), null);
  assert.equal(atkPackDpiStageForSensor("PAW3395SE", 10050, 10050), null);
  assert.equal(atkPackDpiStageForSensor("PAW3395SE", 18100, 18100), null);
});

test("PAW3395SE exposes only the representable vendor range", () => {
  const options = atkDpiOptionsForSensor("PAW3395SE");
  assert.deepEqual(options.slice(0, 3), [200, 250, 300]);
  assert.deepEqual(options.slice(-3), [17800, 17900, 18000]);
  assert.equal(options.length, 277);
  assert.ok(options.every((dpi) => dpi <= 10000 ? dpi % 50 === 0 : dpi % 100 === 0));
  assert.equal(options.includes(10050), false);
  assert.equal(options.includes(10100), true);
  for (const dpi of options) {
    const stage = atkPackDpiStageForSensor("PAW3395SE", dpi, dpi);
    assert.ok(stage, `${dpi} DPI encodes`);
    assert.deepEqual(atkUnpackDpiStageForSensor("PAW3395SE", stage), { x: dpi, y: dpi });
  }
});

test("the verified R1 SE+ identity selects PAW3395SE", () => {
  assert.deepEqual(ATK_PRODUCTS["2,32"], {
    brand: "VXE",
    model: "R1 SE+",
    sensor: "PAW3395SE",
    family: "r1",
    verified: true,
  });
  assert.equal(ATK_SENSORS.PAW3395SE.maxDpi, 18000);
});

test("the F1 Ultimate 2.0 identity selects PAW3950Ultra and no R1 family", () => {
  assert.deepEqual(ATK_PRODUCTS["1,8"], {
    brand: "ATK",
    model: "F1 Ultimate 2.0",
    sensor: "PAW3950Ultra",
    verified: true,
  });
  assert.equal(ATK_PRODUCTS["1,8"]!.family, undefined);
  assert.equal(ATK_SENSORS.PAW3950Ultra.maxDpi, 42000);
});

test("both A9 Mini + identities select PAW3955 Master and no R1 family", () => {
  const verifiedByCidMid: Record<string, boolean> = { "1,31": false, "1,52": true };
  for (const [cidMid, verified] of Object.entries(verifiedByCidMid)) {
    assert.deepEqual(ATK_PRODUCTS[cidMid], {
      brand: "ATK",
      model: "A9 Mini +",
      sensor: "PAW3955Master",
      verified,
    });
    assert.equal(ATK_PRODUCTS[cidMid]!.family, undefined);
  }
  assert.equal(ATK_SENSORS.PAW3955Master.maxDpi, 40000);
});

test("the A9 Plus Nearlink identity selects PAW3395, a 1K ceiling and no R1 family", () => {
  // ATK HUB 3.2.27 maps CID/MID 2,83 on 373b:1115 to "ATK A9 Plus NK" with PAW3395.
  assert.deepEqual(ATK_PRODUCTS["2,83"], {
    brand: "ATK",
    model: "A9 Plus Nearlink",
    sensor: "PAW3395",
    maxPollingHz: 1000,
    verified: true,
  });
  assert.equal(ATK_PRODUCTS["2,83"]!.family, undefined);
});

test("PAW3955 Master uses six-byte rows, not the four-byte mode-nibble layout", () => {
  assert.equal(atkDpiStageLength("PAW3955Master"), 6);
  assert.equal(atkDpiStageLength("PAW3950Ultra"), 4);
  assert.equal(atkDpiStageLength(null), 4);
});

test("a PAW3955 Master stage packs as a raw little-endian value per axis, not a mode nibble", () => {
  assert.deepEqual(atkPackDpiStageForSensor("PAW3955Master", 800, 800), [0x1f, 0x03, 0x1f, 0x03, 0x00, 0x11]);
});

test("PAW3955 Master DPI survives a round trip, including asymmetric axes and the 40k ceiling", () => {
  for (const [x, y] of [[50, 50], [800, 800], [1600, 3200], [39990, 40000], [40000, 40000]]) {
    const stage = atkPackDpiStageForSensor("PAW3955Master", x!, y!);
    assert.ok(stage, `${x},${y} encodes`);
    const sum = stage!.reduce((total, byte) => (total + byte) & 0xff, 0);
    assert.equal(sum, 0x55, `${x},${y} checksum`);
    assert.deepEqual(atkUnpackDpiStageForSensor("PAW3955Master", stage!), { x, y });
  }
});

test("PAW3955 Master rejects a DPI above the confirmed 40,000 ceiling rather than guessing at doubling", () => {
  assert.equal(atkPackDpiStageForSensor("PAW3955Master", 45000, 45000), null);
  assert.equal(atkDpiOptionsForSensor("PAW3955Master").includes(45000), false);
  assert.equal(atkDpiOptionsForSensor("PAW3955Master").at(-1), 40000);
});

test("PAW3955 Master still decodes an existing doubled stage correctly", () => {
  const stage = [0x1f, 0x03, 0x1f, 0x03, 0x11, 0x00];
  const sum = stage.reduce((total, byte) => (total + byte) & 0xff, 0);
  assert.equal(sum, 0x55, "fixture checksum sanity check");
  assert.deepEqual(atkUnpackDpiStageForSensor("PAW3955Master", stage), { x: 1600, y: 1600 });
});

test("Lift-off codes decode to millimetres", () => {
  assert.equal(atkDecodeLiftOff(1), 0.7);
  assert.equal(atkDecodeLiftOff(4), 1);
  assert.equal(atkDecodeLiftOff(11), 1.7);
  assert.equal(atkDecodeLiftOff(0), null);
});

test("lift-off millimetres and codes round trip across the full 0.7-1.7mm range", () => {
  for (let code = ATK_LIFT_OFF_MIN_CODE; code <= ATK_LIFT_OFF_MAX_CODE; code += 1) {
    const mm = atkDecodeLiftOff(code)!;
    assert.equal(atkEncodeLiftOff(mm), code);
  }
  assert.equal(atkDecodeLiftOff(ATK_LIFT_OFF_MIN_CODE), 0.7);
  assert.equal(atkDecodeLiftOff(ATK_LIFT_OFF_MAX_CODE), 1.7);
});

test("R1 polling pack is the 0x0b live-settings row with a checksum pair", () => {
  assert.deepEqual(atkPackVxeR1PollingSetting(1000), [0x0b, 0x01, 0x00, 0x54]);
  assert.deepEqual(atkPackVxeR1PollingSetting(500), [0x0b, 0x02, 0x00, 0x53]);
  assert.deepEqual(atkPackVxeR1PollingSetting(250), [0x0b, 0x03, 0x00, 0x52]);
  assert.equal(atkPackVxeR1PollingSetting(2000), null);
  assert.equal(atkPackVxeR1PollingSetting(125), null);
});

test("R1 polling codes decode back to hertz and reject unknown bytes", () => {
  assert.equal(atkDecodeVxeR1PollingCode(0x01), 1000);
  assert.equal(atkDecodeVxeR1PollingCode(0x02), 500);
  assert.equal(atkDecodeVxeR1PollingCode(0x03), 250);
  assert.equal(atkDecodeVxeR1PollingCode(0x00), null);
  assert.equal(atkDecodeVxeR1PollingCode(0x40), null);
  assert.deepEqual(ATK_VXE_R1_POLLING_RATES, [250, 500, 1000]);
});

test("R1 angle/debounce/LOD settings pack as their live-settings selectors", () => {
  assert.deepEqual(atkPackVxeR1LiveSetting(ATK_VXE_R1_ANGLE_SELECTOR, 0x10), [0x01, 0x10, 0x00, 0x45]);
  assert.deepEqual(atkPackVxeR1LiveSetting(ATK_VXE_R1_ANGLE_SELECTOR, 0x00), [0x01, 0x00, 0x00, 0x55]);
  assert.deepEqual(atkPackVxeR1LiveSetting(ATK_VXE_R1_DEBOUNCE_SELECTOR, 4), [0x02, 0x04, 0x00, 0x51]);
  assert.deepEqual(atkPackVxeR1LiveSetting(ATK_VXE_R1_LOD_SELECTOR, 1), [0x03, 0x01, 0x00, 0x54]);
  assert.deepEqual(atkPackVxeR1LiveSetting(ATK_VXE_R1_LOD_SELECTOR, 2), [0x03, 0x02, 0x00, 0x53]);
});

test("COMPX command ids and R1 storage geometry match the vendor protocol", () => {
  assert.equal(ATK_COMPX_COMMAND.getWirelessMouseOnline, 0x03);
  assert.equal(ATK_COMPX_COMMAND.getCurrentConfig, 0x0e);
  assert.equal(ATK_COMPX_COMMAND.setCurrentConfig, 0x0f);
  assert.equal(ATK_COMPX_COMMAND.reportMouseUpgradeError, 0x5a);
  assert.equal(ATK_COMPX_COMMAND.reportMouseUpgradeStatus, 0x5b);
  assert.equal(ATK_R1_PROFILE_COUNT, 4);
  assert.deepEqual(ATK_R1_BUTTONS.map(({ address }) => address), [0x60, 0x64, 0x68, 0x6c, 0x70, 0x74]);
  assert.equal(ATK_R1_SHORTCUT_BASE, 0x100);
  assert.equal(ATK_R1_SHORTCUT_SLOT_LENGTH, 32);
  assert.equal(ATK_R1_MACRO_BASE, 0x300);
  assert.equal(ATK_R1_MACRO_SLOT_LENGTH, 384);
  assert.equal(ATK_R1_MACRO_SLOT_COUNT, 12);
});

test("current profile, receiver, and pairing replies are decoded without writes", () => {
  assert.equal(atkDecodeCurrentProfile([0]), 0);
  assert.equal(atkDecodeCurrentProfile([3]), 3);
  assert.equal(atkDecodeCurrentProfile([4]), null);
  assert.equal(atkDecodeCurrentProfile([]), null);
  assert.deepEqual(atkDecodeReceiverStatus([1, 0xaa, 0xbb, 0xcc]), {
    online: true,
    status: 1,
    rfId: "CCBBAA",
  });
  assert.deepEqual(atkDecodeReceiverStatus([0, 0, 0, 0]), { online: false, status: 0, rfId: "000000" });
  assert.deepEqual(atkDecodeReceiverStatus([2, 0xaa, 0xbb, 0xcc]), {
    online: false,
    status: 2,
    rfId: "CCBBAA",
  });
  assert.equal(atkDecodeReceiverStatus([1, 2, 3]), null);
  assert.deepEqual(atkDecodePairingStatus([2, 29]), { status: 2, secondsRemaining: 29 });
  assert.equal(atkDecodePairingStatus([2]), null);
});

test("profile selection uses the vendor length field and zero-based bank", () => {
  assert.deepEqual([...atkBuildSetCurrentProfile(2)], [
    0x0f, 0, 0, 0, 1, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x3b,
  ]);
  assert.throws(() => atkBuildSetCurrentProfile(-1), /between 0 and 3/);
  assert.throws(() => atkBuildSetCurrentProfile(4), /between 0 and 3/);
});

test("receiver pairing encodes the exact mouse CID and MID", () => {
  assert.deepEqual([...atkBuildReceiverPairRequest(0x02, 0x20)], [
    0x05, 0, 0, 0, 2, 0x02, 0x20, 0, 0, 0, 0, 0, 0, 0, 0, 0x24,
  ]);
  assert.throws(() => atkBuildReceiverPairRequest(-1, 0x20), /must be bytes/);
  assert.throws(() => atkBuildReceiverPairRequest(0x02, 0x100), /must be bytes/);
});

test("button assignments preserve unknown values and report checksum corruption", () => {
  assert.deepEqual(atkDecodeButtonAssignment([ATK_BUTTON_CLASS.mouse, 1, 0, 0x53]), {
    keyClass: 1,
    value1: 1,
    value2: 0,
    checksum: 0x53,
    checksumValid: true,
    label: "Left click",
    raw: "01 01 00 53",
  });
  const unknown = atkDecodeButtonAssignment([0xfe, 0xaa, 0xbb, 0x00]);
  assert.equal(unknown?.checksumValid, false);
  assert.equal(unknown?.label, "Unknown class 0xfe (0xaa, 0xbb)");
  assert.equal(atkDecodeButtonAssignment([1, 2, 3]), null);
});

test("COMPX firmware parser checks endpoints, geometry, and raw payload CRC", () => {
  const payload = new Uint8Array([1, 2, 3]);
  assert.equal(atkCompxPayloadCrc(payload), 0xaa437fe2);
  const file = new Uint8Array(ATK_COMPX_FIRMWARE_PAYLOAD_OFFSET + payload.length);
  const view = new DataView(file.buffer);
  view.setUint32(0, 0x55552135, true);
  view.setUint32(4, ATK_COMPX_FIRMWARE_HEADER_LENGTH, true);
  view.setUint32(8, payload.length, true);
  view.setUint32(16, 0x315, true);
  view.setUint8(20, 1);
  view.setUint8(21, 2);
  view.setUint8(22, 32);
  const writeField = (index: number, value: string): void => {
    file.set(new TextEncoder().encode(value), 23 + index * 64);
  };
  writeField(0, "ComUsbUpgradeFile");
  writeField(1, "CX52850P");
  writeField(2, "vid_3554&pid_f406&mi_01&col01");
  writeField(3, "vid_3554&pid_f406&mi_01&col02");
  writeField(4, "vid_3554&pid_f58f&mi_01&col05");
  writeField(5, "vid_3554&pid_f58f&mi_01&col05");
  writeField(9, "3395se");
  const prepare = 23 + 7 * 64;
  file.set([49, 1, 6, 0xb0], prepare);
  view.setUint32(prepare + 19, atkCompxPayloadCrc(payload), false);
  file.set(payload, ATK_COMPX_FIRMWARE_PAYLOAD_OFFSET);

  const parsed = atkParseCompxFirmware(file);
  assert.equal(parsed.version, "315");
  assert.equal(parsed.cid, 2);
  assert.equal(parsed.mid, 32);
  assert.equal(parsed.icName, "CX52850P");
  assert.equal(parsed.sensorName, "3395se");
  assert.deepEqual(parsed.normalInput, {
    vendorId: 0x3554,
    productId: 0xf58f,
    path: "vid_3554&pid_f58f&mi_01&col05",
  });
  assert.equal(parsed.payloadCrcValid, true);

  file[ATK_COMPX_FIRMWARE_PAYLOAD_OFFSET] ^= 0xff;
  assert.equal(atkParseCompxFirmware(file).payloadCrcValid, false);
  view.setUint32(8, payload.length + 1, true);
  assert.throws(() => atkParseCompxFirmware(file), /payload length exceeds/);
});

test("F1 Ultimate sensor modes pack the captured 0x00b5 rows", () => {
  assert.deepEqual(atkPackSensorMode(0), [0, 0x55, 6, 0x4f, 0, 0x55]);
  assert.deepEqual(atkPackSensorMode(1), [0, 0x55, 6, 0x4f, 1, 0x54]);
  assert.deepEqual(atkPackSensorMode(2), [0, 0x55, 6, 0x4f, 2, 0x53]);
  assert.equal(atkPackSensorMode(3), null);
  for (const mode of [0, 1, 2] as const) {
    assert.equal(atkDecodeSensorMode(atkPackSensorMode(mode)!), mode);
  }
  assert.equal(atkDecodeSensorMode([0, 0x55, 6, 0x4f, 9, 0x4c]), null);
  assert.equal(atkDecodeSensorMode([0, 0x55, 6, 0x4f, 1, 0x00]), null);
  assert.equal(atkDecodeSensorMode([1, 2, 3]), null);
});

test("F1 Ultimate sensor decode accepts the live row whose first pair varies", () => {
  // HUB-written rows carry [0, 0x55] first; a live localhost readStatus
  // returned [1, 0x54] with mode 1 (Shard) in bytes 4-5.
  assert.equal(atkDecodeSensorMode([1, 0x54, 6, 0x4f, 1, 0x54]), 1);
  assert.equal(atkDecodeSensorMode([1, 0x54, 6, 0x4f, 2, 0x53]), 2);
  assert.equal(atkDecodeSensorMode([0, 0x55, 0, 0x00, 1, 0x54]), null);
});

test("F1 Ultimate anti-mistouch pairs encode 10 ms units", () => {
  assert.deepEqual(atkPackAntiMistouch(0), [0, 0x55]);
  assert.deepEqual(atkPackAntiMistouch(100), [10, 75]);
  assert.deepEqual(atkPackAntiMistouch(500), [50, 35]);
  assert.equal(atkPackAntiMistouch(15), null);
  assert.equal(atkPackAntiMistouch(2560), null);
  assert.equal(atkDecodeAntiMistouch(10, 75), 100);
  assert.equal(atkDecodeAntiMistouch(0, 0x55), 0);
  assert.equal(atkDecodeAntiMistouch(10, 0), null);
});

test("F1 Ultimate dongle-light frames match the captured 0x14 commands", () => {
  for (const [mode, checksum] of [[0, 47], [1, 46], [2, 45], [3, 44]] as const) {
    const frame = atkBuildDongleLight(mode)!;
    assert.deepEqual([...frame.subarray(0, 6)], [0x14, 0, 0, 0, 10, mode]);
    assert.equal(frame[15], checksum);
  }
  assert.equal(atkBuildDongleLight(4), null);
});
