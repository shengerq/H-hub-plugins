/**
 * Razer per-PID capability registry.
 *
 * Razer's protocol is not self-describing: nothing on the wire says which
 * commands a mouse answers, so the only way to know is a table keyed on the
 * exact product id. This is that table, kept apart from the transport in
 * `hid.ts` so adding a model is data rather than code.
 *
 * ## Provenance and what "supported" means here
 *
 * The product list and the transport grouping come from OpenRazer's public
 * supported-device table and mouse driver (see
 * `OPENRAZER_ALL_MICE_DEVELOPER_REFERENCE.md`). Only the entries marked
 * `verified: true` have been exercised against real hardware by this project —
 * everything else is transcribed protocol facts, not a tested driver.
 *
 * Nothing here is a guess about *packets*: every model below is driven by the
 * same 90-byte commands already confirmed on the Viper V3 Pro. What varies per
 * model, and what this table records, is which of those commands are valid,
 * which transaction id the mouse answers on, and what the sensor and radio can
 * actually do.
 *
 * ## Why an unverified entry is safe to ship
 *
 * - A wrong transaction id means the mouse never replies. `readStatus` throws
 *   on the firmware read and the panel reports a connection failure. Nothing
 *   is written.
 * - A wrong capability flag suppresses a command rather than inventing one.
 * - A wrong ceiling is caught by the read-back every setter already performs:
 *   the mouse keeps its own value, the driver notices and reports it.
 *
 * The one thing that would not be safe is sending a command a model does not
 * implement, so unverified models are given the conservative flags below and
 * the asymmetric lift-off *write probe* stays off for all of them.
 *
 * ## Deliberately absent
 *
 * - `legacy/old` (Orochi 2011 `0x0013`, DeathAdder 3.5G `0x0016`/`0x0029`).
 *   These predate the 90-byte report and need direct USB control writes, so
 *   this driver could only ever time out on them.
 * - Orochi V2 Bluetooth (`0x0095`). A Bluetooth HID path is not the USB
 *   control channel and must not be assumed to take the same reports.
 * - Viper Mini (`0x008a`), Viper V4 Pro (`0x00e5`/`0x00e6`) and Cobra
 *   (`0x00a3`), which have their own drivers in this folder. Listing them here
 *   would give two drivers the same device.
 */

import {
  RAZER_TRANSACTION_ID_1F,
  RAZER_TRANSACTION_ID_3F,
  RAZER_TRANSACTION_ID_FF,
} from "./codec.js";

/**
 * OpenRazer's transport families. They differ in response timing, control
 * interface and which commands exist — not in packet layout.
 */
export type RazerTransport =
  | "standard"
  | "index3"
  | "atheris-receiver"
  | "viper-receiver"
  | "new-receiver";

export interface RazerProduct {
  model: string;
  wireless: boolean;
  pollingRates: readonly number[];
  /** Sensor ceiling, per axis. */
  maxDpi: number;
  /** Razer's per-generation transaction id; a mismatch means no reply at all. */
  transactionId: number;
  /** Battery commands only exist on models that have a cell. */
  hasBattery: boolean;
  /**
   * Class `0x02` button mapping (`RAZER_READ`/`RAZER_WRITE.buttonMapping`) has
   * only ever been exercised on the Viper V3 Pro. Other Razer mice may well use
   * a different class or a different control-index scheme, so nothing is
   * offered to them until it has been checked on hardware. Gates both
   * `RazerButtonControl` and `RazerToggleControl` — same command, same risk,
   * no reason to split them.
   *
   * Set per product id, which means per *connection*: the cable and the
   * receiver are separate entries for one mouse and were verified separately.
   * That is not pedantry about provenance — the failure mode is silent.
   * `razerDecodeButtonMapping` reads `type=0x00, len=0x00, value=0x00` as
   * "Disabled", so a transport that does not implement the class answers
   * all-zero and yields a full, ordinary-looking set of controls that every
   * read reports as Disabled and every write appears to accept.
   * `readButtonMappings`'s null-collapse cannot catch it, because the dict
   * comes back populated.
   */
  buttonMapping?: boolean;
  /**
   * The older Chroma lighting commands (class `0x03`: the `0x0a` effect write
   * and the backlight brightness pair). OpenRazer drives some Chroma-era mice
   * this way and others through the extended matrix or plain led commands, and
   * nothing on the wire says which, so this is an allowlist like
   * `buttonMapping`. The effect write has no read-back, so a mouse that
   * accepts it and ignores it would look exactly like one that obeys; only a
   * hardware run can tell.
   */
  standardMatrixLighting?: boolean;
  /** Volatile, zero-based RGB cells using the single-row custom-frame command. */
  oneRowCustomFrameLedCount?: number;
  /**
   * The extended-matrix lighting commands (class `0x0f`: effect `0x02` and
   * the brightness pair `0x04`/`0x84`) on transaction id `0x1f`, addressed per
   * led: all, scroll wheel and logo. OpenRazer drives the Basilisk V3 family
   * this way. Same caveat as `standardMatrixLighting`: the effect write has no
   * read-back, so only a hardware run proves the mouse obeys it.
   */
  extendedMatrixLighting?: boolean;
  /** Also accept a vendor-defined collection as the control interface. */
  vendorControlInterface?: boolean;
  /** DPI storage selector; some generations use the no-store command form. */
  dpiStorageByte?: number;
  transport: RazerTransport;
  /**
   * Use the extended polling command (a divisor of 8000) rather than the legacy
   * one (a divisor of 1000). This is a property of the generation, not of the
   * connection: the Viper 8KHz is wired and needs the extended command, while
   * the older HyperSpeed receivers are wireless and only answer the legacy one.
   */
  highRatePolling: boolean;
  /**
   * Commit an extended polling change with a second write, selector `0x01`,
   * on this transaction id. OpenRazer sends the ordinary selector-`0x00`
   * write first. The HyperPolling dongle puts the commit on `0xff`; the wired
   * DeathAdder V3 keeps both writes on `0x1f`. Omitted when one write is enough.
   */
  extendedPollingCommitTransactionId?: number;
  /**
   * The mouse implements the class `0x0b` tracking distance.
   *
   * This cannot be probed. The Basilisk X HyperSpeed answers `0x0b`/`0x85` with
   * status `0x02` and an all-zero payload, which decodes as a legitimate
   * "Low" — so "the command replied" is not evidence the mouse has the feature,
   * and offering the control on that basis produced a picker where every level
   * failed: `0x01` was acknowledged and stored nothing, `0x02` was refused
   * outright.
   *
   * There is no reply that distinguishes "no lift-off control" from "Low at the
   * bottom of the range", so this has to be stated per product.
   */
  liftOff: boolean;
  /**
   * The mouse additionally stores separate lift-off and landing heights, and
   * the mode can be established by the pair write's own status.
   *
   * That probe is a *write*, so it is only enabled where the command has been
   * confirmed on hardware. Implies `liftOff`.
   */
  asymmetricLiftOff: boolean;
  /** Confirmed against real hardware by this project. */
  verified: boolean;
  /**
   * The control channel sits on a collection Chrome classifies as a plain mouse
   * and strips feature reports from, so WebHID can never reach it no matter how
   * many interfaces are granted. The registry entry stays so the native HAL
   * transport still has a config, but `../vendors.ts` must not offer the id in
   * the WebHID picker.
   */
  nativeOnly?: boolean;
  /**
   * Polling rates and which command encodes them follow the paired mouse, not a
   * fixed list for this product id. The driver probes which command answers and
   * offers the matching 1 kHz or 8 kHz ladder. `pollingRates` / `highRatePolling`
   * are then only the pre-probe defaults. Mouse Dock Pro is the only case.
   */
  probePollingRates?: boolean;
  /**
   * Link label used instead of "HyperSpeed receiver" / "Wired USB" — for docks
   * that are neither.
   */
  connectionLabel?: string;
}

/** Everything a preset supplies. The transaction id is deliberately not here. */
type ProductDefaults = Omit<RazerProduct, "model" | "transactionId">;

// The cable tops out at 1000 Hz on the models verified so far, which is also
// the ceiling the legacy polling command can encode.
export const RATES_1K: readonly number[] = [125, 500, 1000];
export const RATES_8K: readonly number[] = [125, 500, 1000, 2000, 4000, 8000];

/**
 * Products answering on `0x3f`, audited against OpenRazer's mouse driver.
 *
 * ## Why this is a flat list and not a field on the transport presets
 *
 * It was a preset field, and that was wrong for 26 of the 107 products. The
 * transaction id does not follow the transport group, the connection, the
 * model's age or its marketing family — OpenRazer picks it per product id, and
 * the groups interleave all three values:
 *
 * - Basilisk `0x0064` is `0x3f` while Basilisk V2 `0x0085` is `0x1f` and
 *   Basilisk X HyperSpeed `0x0083` is `0xff`.
 * - Viper `0x0078` is `0xff`, Viper 8KHz `0x0091` is `0xff`, Viper Mini SE
 *   `0x009e` is `0x1f`.
 * - Inside one `new-receiver` group: Lancehead Wireless `0x006f` is `0x3f`,
 *   Pro Click `0x0077` is `0x1f`, Basilisk X HyperSpeed `0x0083` is `0xff`.
 *
 * A wrong id is silent — the mouse never replies — so there is no failure mode
 * to catch an inherited guess. Keeping the ids in one auditable block, rather
 * than spread across presets that imply a pattern, is what stops that
 * inheritance happening again.
 */
const TRANSACTION_3F: readonly number[] = [
  0x0050, 0x0059, 0x005a, 0x005c, 0x0060, 0x0064, 0x0065, 0x006f, 0x0070,
  0x0072, 0x0073, 0x007c, 0x007d, 0x0084, 0x008c,
  // --- Diverging from OpenRazer, on purpose ---------------------------------
  // Viper Ultimate. OpenRazer sends `0xff` on every command for both ids, but
  // a hardware report has `0x1f` silent and `0x3f` reading firmware, DPI,
  // polling and battery correctly. Observed behaviour wins over the reference,
  // and the mouse may well accept both. Worth re-testing against `0xff`.
  0x007a, 0x007b,
  // DeathAdder Essential. Predates this audit: the driver has always sent
  // `0x3f` here on the stated grounds that OpenRazer does, which the driver
  // source does not bear out — it lists all three ids under `0xff`. Left as it
  // was rather than changed blind, because nothing has connected one either
  // way. Flagged in TESTING.md as the next thing to check on this family.
  0x006e, 0x0071, 0x0098,
];

/** Products answering on `0x1f`. Same provenance as the list above. */
const TRANSACTION_1F: readonly number[] = [
  0x0062, 0x006c, 0x0077, 0x0080, 0x0085, 0x0086, 0x0088, 0x008d, 0x008f,
  0x0090, 0x0094, 0x0096, 0x0099, 0x009a, 0x009c, 0x009e, 0x009f, 0x00a1,
  // Mouse Dock Pro is not in OpenRazer's mouse table; hardware with a Naga V2
  // Pro paired answers on `0x1f` like that generation's mice.
  0x00a4, 0x00a5, 0x00a6, 0x00a7, 0x00a8, 0x00aa, 0x00ab, 0x00af, 0x00b0, 0x00b2, 0x00b3,
  0x00b4, 0x00b6, 0x00b7, 0x00b8, 0x00b9, 0x00be, 0x00bf, 0x00c0, 0x00c1,
  0x00c2, 0x00c3, 0x00c4, 0x00c5, 0x00c7, 0x00c8, 0x00cb, 0x00cc, 0x00cd,
  0x00d0, 0x00d1, 0x00d3, 0x00d4, 0x00d6, 0x00d7,
  // Viper V3 Pro SE. OpenRazer PR #2818 subclasses the Viper V3 Pro classes,
  // and the transaction id is a property of those classes — so the id comes
  // from the same source as `0x00c0`/`0x00c1` above rather than from the family
  // name. The SE reference separately mentions `0xff`, but only for the
  // HyperPolling dongle indicator command, which this driver does not send.
  0x00de, 0x00df,
  // DeathAdder V4 Pro Carbon Fiber Edition. Same electronics as `0x00be`/
  // `0x00bf` under a cosmetic SKU (Razer's own live `AvailableDevices.json`
  // groups them the same way, receiver id one above the mouse id), so it
  // shares that pair's transaction id — not independently audited.
  0x00ef, 0x00f0,
];

/**
 * `0xff` is the fallback because it is the id the largest group uses, not
 * because it is safe to assume: a product missing from both lists above has
 * simply not been audited, and will be silent if `0xff` is wrong for it.
 */
function transactionIdFor(productId: number): number {
  if (TRANSACTION_3F.includes(productId)) return RAZER_TRANSACTION_ID_3F;
  if (TRANSACTION_1F.includes(productId)) return RAZER_TRANSACTION_ID_1F;
  return RAZER_TRANSACTION_ID_FF;
}

/**
 * Sensor ceilings by generation, from published specifications rather than from
 * the mouse — Razer exposes no "what is your maximum DPI" command. A ceiling
 * that is too high costs a failed read-back on a value the mouse will not hold;
 * one that is too low would refuse a value it would have taken, so these err
 * generous where a model's exact figure is not encoded in its name.
 */
const DPI_PRE_CHROMA = 8_200;
const DPI_CHROMA = 16_000;
const DPI_FOCUS = 20_000;
const DPI_FOCUS_PRO = 30_000;
const DPI_FOCUS_PRO_35K = 35_000;
// DeathAdder V4 Pro only. OpenRazer PR #2508 documents this model's own
// `DPI_MAX = 45000` (and raised the shared set-DPI clamp to match) — a higher
// ceiling than the rest of the 35K-sensor generation above, so it gets its
// own constant rather than reusing DPI_FOCUS_PRO_35K.
const DPI_DEATHADDER_V4_PRO = 45_000;

/**
 * Chroma-era and older wired mice. OpenRazer's `standard` group answers on the
 * original transaction id, and which interface carries the control channel
 * varies by revision, so a vendor-defined collection is accepted too.
 */
const STANDARD = {
  transport: "standard",
  wireless: false,
  pollingRates: RATES_1K,
  maxDpi: DPI_CHROMA,
  hasBattery: false,
  vendorControlInterface: true,
  highRatePolling: false,
  liftOff: false,
  asymmetricLiftOff: false,
  verified: false,
} as const satisfies ProductDefaults;

/** Same generation, but a model with a cell and a charging dock or receiver. */
const STANDARD_WIRELESS = {
  ...STANDARD,
  wireless: true,
  hasBattery: true,
} as const satisfies ProductDefaults;

/**
 * OpenRazer routes Naga X, Basilisk V3 and Basilisk V3 35K through USB control
 * transfer index 3. WebHID cannot select a `wIndex`, so the browser has to be
 * pointed at the HID collection belonging to that interface instead: the picker
 * offers every interface and the wrong one simply never answers.
 */
const INDEX3 = {
  ...STANDARD,
  transport: "index3",
  maxDpi: DPI_FOCUS_PRO,
} as const satisfies ProductDefaults;

/** Atheris and Orochi V2 receivers, which need a longer response window. */
const ATHERIS_RECEIVER = {
  ...STANDARD,
  transport: "atheris-receiver",
  wireless: true,
  hasBattery: true,
  maxDpi: DPI_FOCUS,
} as const satisfies ProductDefaults;

/**
 * The modern HyperSpeed generation, wired half. These are wireless mice on a
 * cable, so they keep their battery commands; the cable itself runs at the
 * legacy ceiling.
 */
const MODERN_WIRED = {
  transport: "new-receiver",
  wireless: false,
  pollingRates: RATES_1K,
  maxDpi: DPI_FOCUS,
  hasBattery: true,
  highRatePolling: false,
  liftOff: false,
  asymmetricLiftOff: false,
  verified: false,
} as const satisfies ProductDefaults;

/** The stock 1000 Hz receiver these ship with. */
const MODERN_RECEIVER = {
  ...MODERN_WIRED,
  wireless: true,
  highRatePolling: true,
} as const satisfies ProductDefaults;

/**
 * Older HyperSpeed receivers, which predate the extended polling command and
 * answer only the legacy one.
 */
const LEGACY_RECEIVER = {
  ...MODERN_RECEIVER,
  highRatePolling: false,
} as const satisfies ProductDefaults;

/** Receivers that ship as HyperPolling dongles and reach 8000 Hz. */
const HYPERPOLLING_RECEIVER = {
  ...MODERN_RECEIVER,
  pollingRates: RATES_8K,
  maxDpi: DPI_FOCUS_PRO_35K,
} as const satisfies ProductDefaults;

/** Viper Ultimate / Viper Mini SE / DeathAdder V2 Pro timing group. */
const VIPER_RECEIVER_WIRED = {
  ...MODERN_WIRED,
  transport: "viper-receiver",
} as const satisfies ProductDefaults;

const VIPER_RECEIVER_WIRELESS = {
  ...MODERN_RECEIVER,
  transport: "viper-receiver",
} as const satisfies ProductDefaults;

/**
 * DeathAdder Essential family. 6400 DPI is the officially published maximum
 * and the ceiling the vendor software offers.
 *
 * Not verified: it shipped before this registry existed and TESTING.md has
 * always carried it under "not yet hardware-tested". An earlier revision of
 * this file marked it verified by mistake, which was wrong in both directions —
 * it suppressed the "untested model" label and armed the strict battery read.
 */
const DEATHADDER_ESSENTIAL = {
  transport: "standard",
  wireless: false,
  pollingRates: RATES_1K,
  maxDpi: 6400,
  hasBattery: false,
  vendorControlInterface: true,
  highRatePolling: false,
  liftOff: false,
  asymmetricLiftOff: false,
  verified: false,
} as const satisfies ProductDefaults;

const VIPER_V2_PRO = {
  transport: "new-receiver",
  maxDpi: DPI_FOCUS_PRO,
  hasBattery: true,
  // Stock receiver, not an 8K HyperPolling dongle.
  pollingRates: RATES_1K,
  liftOff: true,
  asymmetricLiftOff: true,
  verified: true,
} as const;

const VIPER_V3_PRO = {
  transport: "viper-receiver",
  maxDpi: DPI_FOCUS_PRO_35K,
  hasBattery: true,
  liftOff: true,
  asymmetricLiftOff: true,
  // Class 0x02 is confirmed on both of this model's connections, so it belongs
  // on the shared preset rather than on one product id. It sat on `0x00c1`
  // alone while only the receiver had been exercised.
  buttonMapping: true,
  verified: true,
} as const;

/**
 * Every product this driver claims, before the audited transaction id is
 * attached. Build `RAZER_PRODUCTS` from this rather than reading it directly.
 *
 * The `verified: true` entries are the ones a hardware report has covered;
 * the rest come from the OpenRazer reference and have never been connected.
 */
const PRODUCT_DEFINITIONS: ReadonlyArray<[number, Omit<RazerProduct, "transactionId">]> = [
  // ---- Verified on hardware -------------------------------------------------
  [0x00a5, { model: "Viper V2 Pro", wireless: false, highRatePolling: false, ...VIPER_V2_PRO }],
  [0x00a6, { model: "Viper V2 Pro", wireless: true, highRatePolling: true, ...VIPER_V2_PRO }],
  [0x00c0, { model: "Viper V3 Pro", wireless: false, pollingRates: RATES_1K, highRatePolling: false, ...VIPER_V3_PRO }],
  [0x00c1, { model: "Viper V3 Pro", wireless: true, pollingRates: RATES_8K, highRatePolling: true, ...VIPER_V3_PRO }],
  [0x006e, { model: "DeathAdder Essential", ...DEATHADDER_ESSENTIAL }],
  [0x0071, { model: "DeathAdder Essential White Edition", ...DEATHADDER_ESSENTIAL }],
  [0x0098, { model: "DeathAdder Essential (2021)", ...DEATHADDER_ESSENTIAL }],

  // ---- standard: wired, original transaction id -----------------------------
  // Ceilings encoded in a model's own name are used as given; the rest take the
  // generation default.
  [0x0015, { model: "Naga", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x001f, { model: "Naga Epic", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0020, { model: "Abyssus 1800", ...STANDARD, maxDpi: 1800 }],
  [0x0024, { model: "Mamba 2012 (Wired)", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0025, { model: "Mamba 2012", ...STANDARD_WIRELESS, maxDpi: DPI_PRE_CHROMA }],
  [0x002e, { model: "Naga 2012", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x002f, { model: "Imperator 2012", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0032, { model: "Ouroboros 2012", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0034, { model: "Taipan", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0036, { model: "Naga Hex (Red)", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0037, { model: "DeathAdder 2013", ...STANDARD, maxDpi: 6400 }],
  [0x0038, { model: "DeathAdder 1800", ...STANDARD, maxDpi: 1800 }],
  [0x0039, { model: "Orochi 2013", ...STANDARD_WIRELESS, maxDpi: DPI_PRE_CHROMA }],
  [0x003e, { model: "Naga Epic Chroma (Wired)", ...STANDARD }],
  [0x003f, { model: "Naga Epic Chroma", ...STANDARD_WIRELESS }],
  [0x0040, { model: "Naga 2014", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  [0x0041, { model: "Naga Hex", ...STANDARD }],
  [0x0042, { model: "Abyssus 2014", ...STANDARD, maxDpi: 1800 }],
  [0x0043, { model: "DeathAdder Chroma", ...STANDARD }],
  [0x0044, { model: "Mamba (Wired)", ...STANDARD }],
  [0x0045, { model: "Mamba", ...STANDARD_WIRELESS }],
  [0x0046, { model: "Mamba Tournament Edition", ...STANDARD }],
  [0x0048, { model: "Orochi (Wired)", ...STANDARD, maxDpi: DPI_PRE_CHROMA }],
  // Verified on firmware 1.0 over the cable, through OpenMouse Bridge on
  // Windows: identity, DPI (1800) and polling (500 Hz) read back, and 800 DPI
  // and 1000 Hz each wrote, read back and were restored. The polling sampler
  // saw dropouts, so the rate was read back but not measured. The stage read
  // gave nothing usable, so no stage editor is offered. Lighting follows
  // OpenRazer's standard-matrix commands and has not been tried on it yet.
  [0x004c, { model: "Diamondback Chroma", ...STANDARD, verified: true, standardMatrixLighting: true, oneRowCustomFrameLedCount: 21 }],
  [0x004f, { model: "DeathAdder 2000", ...STANDARD, maxDpi: 2000 }],
  [0x0050, { model: "Naga Hex V2", ...STANDARD }],
  [0x0053, { model: "Naga Chroma", ...STANDARD }],
  [0x0054, { model: "DeathAdder 3500", ...STANDARD, maxDpi: 3500 }],
  [0x0059, { model: "Lancehead (Wired)", ...STANDARD }],
  [0x005a, { model: "Lancehead", ...STANDARD_WIRELESS }],
  [0x005b, { model: "Abyssus V2", ...STANDARD, maxDpi: 5000 }],
  [0x005c, { model: "DeathAdder Elite", ...STANDARD }],
  [0x005e, { model: "Abyssus 2000", ...STANDARD, maxDpi: 2000 }],
  [0x0060, { model: "Lancehead Tournament Edition", ...STANDARD }],
  [0x0064, { model: "Basilisk", ...STANDARD }],
  [0x0065, { model: "Basilisk Essential", ...STANDARD, maxDpi: 6400 }],
  [0x0067, { model: "Naga Trinity", ...STANDARD }],
  [0x006a, { model: "Abyssus Elite (D.Va Edition)", ...STANDARD, maxDpi: 7200 }],
  [0x006b, { model: "Abyssus Essential", ...STANDARD, maxDpi: 7200 }],
  [0x006c, { model: "Mamba Elite", ...STANDARD }],
  [0x0084, { model: "DeathAdder V2", ...STANDARD, maxDpi: DPI_FOCUS, dpiStorageByte: 0x00 }],
  [0x0085, { model: "Basilisk V2", ...STANDARD, maxDpi: DPI_FOCUS }],
  [0x008c, { model: "DeathAdder V2 Mini", ...STANDARD, maxDpi: 8500 }],
  [0x008d, { model: "Naga Left-Handed Edition 2020", ...STANDARD, maxDpi: DPI_FOCUS }],
  // Wired, but the whole point of the model is 8000 Hz, which the legacy
  // polling command cannot encode.
  [0x0091, { model: "Viper 8KHz", ...STANDARD, maxDpi: DPI_FOCUS, pollingRates: RATES_8K, highRatePolling: true }],
  [0x00a1, { model: "DeathAdder V2 Lite", ...STANDARD, maxDpi: 8500 }],
  // Hardware report: the legacy read `00/85` comes back with status 0x05 (not
  // supported) and the extended read `00/c0` answers 8000/4, so the mouse was
  // already sitting at 2000 Hz while this row still offered a 1000 Hz ceiling.
  // Wired, like the Viper 8KHz above, but HyperPolling is the point of the
  // model and the legacy command cannot encode it.
  //
  // The extended write alone does not stick. Issue #222: an 8000 → 2000
  // write was acknowledged and the read-back stayed at 8000. OpenRazer
  // (`razer_attr_write_poll_rate`) follows selector `0x00` with selector
  // `0x01`, both on transaction `0x1f` — not the dongle's `0xff` commit.
  [0x00b2, {
    model: "DeathAdder V3",
    ...STANDARD,
    maxDpi: DPI_FOCUS_PRO,
    pollingRates: RATES_8K,
    highRatePolling: true,
    extendedPollingCommitTransactionId: RAZER_TRANSACTION_ID_1F,
  }],
  // Standalone HyperPolling Wireless Dongle. OpenRazer reads extended polling
  // with transaction 0x1f and commits a change with two writes: selector 0x00
  // on 0x1f, then selector 0x01 on 0xff. Settings are forwarded to the paired
  // mouse, so expose the Focus Pro ceiling used by the DeathAdder V3 Pro while
  // leaving the entry unverified until OpenMouse hardware captures it.
  [0x00b3, {
    model: "HyperPolling Wireless Dongle",
    ...HYPERPOLLING_RECEIVER,
    transport: "viper-receiver",
    maxDpi: DPI_FOCUS_PRO,
    vendorControlInterface: true,
    extendedPollingCommitTransactionId: RAZER_TRANSACTION_ID_FF,
    connectionLabel: "HyperPolling Wireless Dongle",
  }],
  // ---- index3: wired, control channel on USB interface 3 --------------------
  [0x0096, { model: "Naga X", ...INDEX3, maxDpi: 18_000 }],
  // Lighting follows OpenRazer's extended-matrix commands for these two ids
  // (wave, spectrum, static and brightness on the all/scroll/logo leds, all on
  // 0x1f) and has not been tried on hardware yet.
  [0x0099, { model: "Basilisk V3", ...INDEX3, maxDpi: 26_000, extendedMatrixLighting: true }],
  [0x00cb, { model: "Basilisk V3 35K", ...INDEX3, maxDpi: DPI_FOCUS_PRO_35K, extendedMatrixLighting: true }],

  // ---- atheris-receiver: longer receiver wait -------------------------------
  [0x0062, { model: "Atheris", ...ATHERIS_RECEIVER, maxDpi: 7200 }],
  [0x0094, { model: "Orochi V2", ...ATHERIS_RECEIVER, maxDpi: 18_000 }],

  // ---- viper-receiver -------------------------------------------------------
  [0x007a, { model: "Viper Ultimate (Wired)", ...VIPER_RECEIVER_WIRED }],

  // Confirmed on hardware (PR #45): the dongle's Generic-Desktop-Mouse
  // interface is Chrome-protected, so every collection is feat[none] and
  // sendFeatureReport fails on any id. Native HAL only.
  [0x007b, { model: "Viper Ultimate", ...VIPER_RECEIVER_WIRELESS, nativeOnly: true }],
  [0x007c, { model: "DeathAdder V2 Pro (Wired)", ...VIPER_RECEIVER_WIRED }],
  [0x007d, { model: "DeathAdder V2 Pro", ...VIPER_RECEIVER_WIRELESS }],
  [0x009e, { model: "Viper Mini Signature Edition (Wired)", ...VIPER_RECEIVER_WIRED, maxDpi: DPI_FOCUS_PRO }],
  [0x009f, { model: "Viper Mini Signature Edition", ...VIPER_RECEIVER_WIRELESS, maxDpi: DPI_FOCUS_PRO, pollingRates: RATES_8K }],
  // Verified on hardware with the stock HyperSpeed receiver, and the first
  // model to prove `highRatePolling` is genuinely per-PID rather than a
  // property of the transport group or of being wireless: this receiver
  // answers only the legacy divisor-of-1000 command and rejects the extended
  // one (`0x00`/`0x40`) as unsupported. 125/500/1000 Hz were each written and
  // read back.
  //
  // Do not "tidy" this back onto the group default. 0x00a6 is the standing
  // counter-example in the other direction — a 1000 Hz receiver that does use
  // the extended command — so neither the group nor the rate ceiling predicts
  // this, and it can only be settled per product.
  // Lift-off reported working here, so the tracking control stays on — but not
  // the asymmetric pair, which was never exercised. If this model turns out to
  // answer `0x0b`/`0x85` with zeros the way the Basilisk X HyperSpeed does, it
  // will show a permanent "Low" and refuse every level; that is the thing to
  // check before trusting it.
  [0x00b8, { model: "Viper V3 HyperSpeed", ...VIPER_RECEIVER_WIRELESS, highRatePolling: false, liftOff: true, maxDpi: DPI_FOCUS_PRO, verified: true }],

  // Viper V3 Pro SE (`RZ01-0455`). OpenRazer PR #2818 implements it by
  // subclassing the Viper V3 Pro rather than writing a new codec, so the packet
  // format, the DPI pair and the extended polling commands are the same ones
  // `0x00c0`/`0x00c1` already use.
  //
  // Two things are deliberately not inherited from that pair. `verified` stays
  // false — nothing has connected one here, and the V3 Pro's flag was earned by
  // a hardware report on its own product ids. `liftOff` stays false because it
  // cannot be probed: a mouse without the feature answers `0x0b`/`0x85` with
  // status `0x02` and zeros, which decodes as a legitimate "Low".
  //
  // Polling: settled on hardware, and it went the other way from OpenRazer.
  // `0x00df` first shipped here with the 8 kHz ladder because OpenRazer's SE
  // wireless class exposes it. A capture on the stock HyperSpeed receiver has
  // the extended read (`0x00`/`0xc0`) answered with status `0x05` — not
  // supported — and the legacy read (`0x00`/`0x85`) answering a divisor of 1,
  // i.e. 1000 Hz. An outright refusal, not a write that confirms and does
  // nothing, so this needs no rate measurement to settle.
  //
  // Razer's own specification agrees: "1000 Hz normally, up to 8000 Hz with
  // HyperPolling Dongle". The dongle is a different receiver and would enumerate
  // as its own product id; this row describes the one in the box.
  [0x00de, {
    model: "Viper V3 Pro SE (Wired)",
    ...VIPER_RECEIVER_WIRED,
    maxDpi: DPI_FOCUS_PRO_35K,
    // Which interface carries the control channel has not been established for
    // this model, so accept the vendor-defined shape as well as the plain
    // mouse one and let the exchange itself reject what cannot answer.
    vendorControlInterface: true,
  }],
  [0x00df, {
    model: "Viper V3 Pro SE",
    ...VIPER_RECEIVER_WIRELESS,
    maxDpi: DPI_FOCUS_PRO_35K,
    pollingRates: RATES_1K,
    highRatePolling: false,
    vendorControlInterface: true,
  }],

  // ---- new-receiver ---------------------------------------------------------
  // Dock, not a mouse: settings pass through to whichever mouse is paired.
  // Polling rates are discovered per session — a Naga stays on the 1 kHz ladder,
  // while a HyperPolling-capable mouse unlocks the 8 kHz one.
  [0x00a4, {
    model: "Mouse Dock Pro",
    ...MODERN_RECEIVER,
    // Verified only with a Naga V2 Pro paired (Focus Pro 30k). A higher dock
    // ceiling for 35k mice is untested through this path, so keep the observed
    // sensor limit rather than advertising an unverified range.
    maxDpi: DPI_FOCUS_PRO,
    probePollingRates: true,
    connectionLabel: "Mouse Dock Pro",
    // Conservative pre-probe defaults; `readPollingRateHz` replaces both once
    // it knows which command the paired mouse answers.
    pollingRates: RATES_1K,
    highRatePolling: true,
    verified: true,
  }],
  [0x006f, { model: "Lancehead Wireless", ...LEGACY_RECEIVER, maxDpi: DPI_CHROMA }],
  [0x0070, { model: "Lancehead Wireless (Wired)", ...MODERN_WIRED, maxDpi: DPI_CHROMA }],
  [0x0072, { model: "Mamba Wireless", ...LEGACY_RECEIVER, maxDpi: DPI_CHROMA }],
  [0x0073, { model: "Mamba Wireless (Wired)", ...MODERN_WIRED, maxDpi: DPI_CHROMA }],
  [0x0077, { model: "Pro Click", ...LEGACY_RECEIVER, maxDpi: DPI_CHROMA }],
  [0x0080, { model: "Pro Click (Wired)", ...MODERN_WIRED, maxDpi: DPI_CHROMA }],
  [0x0083, { model: "Basilisk X HyperSpeed", ...LEGACY_RECEIVER, maxDpi: DPI_CHROMA }],
  [0x0086, { model: "Basilisk Ultimate (Wired)", ...MODERN_WIRED }],
  [0x0088, { model: "Basilisk Ultimate", ...LEGACY_RECEIVER }],
  [0x008f, { model: "Naga Pro (Wired)", ...MODERN_WIRED }],
  [0x0090, { model: "Naga Pro", ...LEGACY_RECEIVER }],
  [0x009a, { model: "Pro Click Mini", ...LEGACY_RECEIVER, maxDpi: 12_000 }],
  [0x009c, { model: "DeathAdder V2 X HyperSpeed", ...LEGACY_RECEIVER, maxDpi: 14_000 }],
  [0x00a7, { model: "Naga V2 Pro (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO, verified: true }],
  [0x00a8, { model: "Naga V2 Pro", ...MODERN_RECEIVER, maxDpi: DPI_FOCUS_PRO, verified: true }],
  [0x00aa, { model: "Basilisk V3 Pro (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO }],
  [0x00ab, { model: "Basilisk V3 Pro", ...MODERN_RECEIVER, maxDpi: DPI_FOCUS_PRO }],
  [0x00af, { model: "Cobra Pro (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO }],
  [0x00b0, { model: "Cobra Pro", ...MODERN_RECEIVER, maxDpi: DPI_FOCUS_PRO }],
  [0x00b4, { model: "Naga V2 HyperSpeed", ...LEGACY_RECEIVER, maxDpi: DPI_FOCUS_PRO }],
  // Verified on firmware 2.1 over the cable: same 13 write/read-back steps as
  // the receiver below, polling measured (126 Hz peak at 125), battery reads
  // "Charging" and climbs while plugged in.
  [0x00b6, { model: "DeathAdder V3 Pro (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO, verified: true }],
  // Hardware report: the extended command is accepted and reads back, but the
  // measured report rate stays at 1000 Hz whatever is written. This model ships
  // with the stock 1000 Hz HyperSpeed receiver, not the 8000 Hz HyperPolling
  // dongle (`0x00b3`, which this driver does not claim), so the extended
  // encoding was addressing a ceiling the hardware does not have. `0x00c3` is
  // the same model on a second product id and is likely the same, but nobody
  // has measured it — see TESTING.md.
  //
  // Verified on firmware 2.1 with the legacy command: 125/500/1000 Hz each
  // round-tripped AND measured (124 Hz and 842 Hz peak `pointerrawupdate` at
  // 125 and 1000), DPI, auto sleep and low power persisted across a reconnect
  // and a power cycle. The wired `0x00b6` above was verified the same way.
  [0x00b7, { model: "DeathAdder V3 Pro", ...MODERN_RECEIVER, highRatePolling: false, maxDpi: DPI_FOCUS_PRO, verified: true }],
  [0x00b9, { model: "Basilisk V3 X HyperSpeed", ...LEGACY_RECEIVER, maxDpi: 18_000 }],
  // Was nativeOnly: the control channel used to sit on a Chrome-protected
  // collection (with Synapse fully stopped the diagnostics harness got "no
  // feature report channel" on every interface, wired and wireless both —
  // see git blame). Razer's own live `AvailableDevices.json` on Synapse Web
  // now lists this model (productId 190/191, i.e. 0x00be/0x00bf), meaning a
  // firmware or descriptor update moved the control channel off that
  // collection. Re-tested and confirmed reachable over WebHID.
  // OpenRazer PR #2508: both the cable and the HyperPolling dongle reach
  // 8000 Hz on this model (the wired half is not capped at MODERN_WIRED's
  // usual 1000 Hz — a HyperPolling receiver ships in the box, so the cable
  // gets the same ceiling as the dongle).
  [0x00be, { model: "DeathAdder V4 Pro (Wired)", ...MODERN_WIRED, pollingRates: RATES_8K, highRatePolling: true, maxDpi: DPI_DEATHADDER_V4_PRO }],
  [0x00bf, { model: "DeathAdder V4 Pro", ...HYPERPOLLING_RECEIVER, maxDpi: DPI_DEATHADDER_V4_PRO }],
  // Carbon Fiber Edition — cosmetic SKU on its own product ids, listed
  // alongside 0x00be/0x00bf in Razer's live AvailableDevices.json
  // (productId 239/240). Not independently hardware-tested; same specs
  // assumed as the standard edition until proven otherwise.
  [0x00ef, { model: "DeathAdder V4 Pro Carbon Fiber Edition (Wired)", ...MODERN_WIRED, pollingRates: RATES_8K, highRatePolling: true, maxDpi: DPI_DEATHADDER_V4_PRO }],
  [0x00f0, { model: "DeathAdder V4 Pro Carbon Fiber Edition", ...HYPERPOLLING_RECEIVER, maxDpi: DPI_DEATHADDER_V4_PRO }],
  [0x00c2, { model: "DeathAdder V3 Pro (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO }],
  [0x00c3, { model: "DeathAdder V3 Pro", ...MODERN_RECEIVER, maxDpi: DPI_FOCUS_PRO }],
  [0x00c4, { model: "DeathAdder V3 HyperSpeed (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO }],
  [0x00c5, { model: "DeathAdder V3 HyperSpeed", ...LEGACY_RECEIVER, maxDpi: DPI_FOCUS_PRO }],
  [0x00c7, { model: "Pro Click V2 Vertical Edition (Wired)", ...MODERN_WIRED }],
  [0x00c8, { model: "Pro Click V2 Vertical Edition", ...LEGACY_RECEIVER }],
  [0x00cc, { model: "Basilisk V3 Pro 35K (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO_35K }],
  [0x00cd, { model: "Basilisk V3 Pro 35K", ...HYPERPOLLING_RECEIVER }],
  [0x00d0, { model: "Pro Click V2 (Wired)", ...MODERN_WIRED }],
  [0x00d1, { model: "Pro Click V2", ...LEGACY_RECEIVER }],
  [0x00d3, { model: "Basilisk Mobile (Wired)", ...MODERN_WIRED, maxDpi: 18_000 }],
  [0x00d4, { model: "Basilisk Mobile", ...LEGACY_RECEIVER, maxDpi: 18_000 }],
  [0x00d6, { model: "Basilisk V3 Pro 35K Phantom Green (Wired)", ...MODERN_WIRED, maxDpi: DPI_FOCUS_PRO_35K }],
  [0x00d7, { model: "Basilisk V3 Pro 35K Phantom Green", ...HYPERPOLLING_RECEIVER }],
];

/**
 * Every product, with its audited transaction id attached.
 *
 * Joined here rather than written into each row so there is exactly one place
 * the id can come from, and no preset can supply one by inheritance.
 */
export const RAZER_PRODUCTS: ReadonlyMap<number, RazerProduct> = new Map(
  PRODUCT_DEFINITIONS.map(([productId, product]) => [
    productId,
    { ...product, transactionId: transactionIdFor(productId) },
  ]),
);

/** Product ids for the WebHID picker filters in `../vendors.ts`. */
export const RAZER_PRODUCT_IDS: readonly number[] = [...RAZER_PRODUCTS.keys()];
