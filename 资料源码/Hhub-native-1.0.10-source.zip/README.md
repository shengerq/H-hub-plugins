# Hhub 1.0.10 native plugins and driver installer source

Host UI/Core: host-source (Visual Studio 2022 C++ v143, Windows SDK, Windows App SDK). Exact standalone installer source: driver-installer-source/Hhub.AudioInstaller.vcxproj. Run MSBuild with /p:Configuration=Release /p:Platform=x64. The resource file uses portable relative payload paths.

Driver: unmodified official signed FxSound x64 driver. Upstream source https://github.com/fxsound2/fxsound-driver . Included payload/LICENSE.txt (AGPL-3.0) and payload/license.rtf (Microsoft Limited Public License). Hhub additions retain the existing source license; FxSound DSP source and license are in host-source/vendor/fxsound/.

Plugin binaries are optional .hhub assets, extracted only after user confirmation. Driver installer --verify-only <report> validates signature without installing. --from-plugin <report> is the integrated UI mode; installation still requires Windows administrator approval. Standalone execution retains its own confirmation dialog.

No signing credentials, personal profiles, pairing secrets, caches or compiled host binaries are included.
