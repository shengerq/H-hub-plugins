﻿param([Parameter(Mandatory=$true)][string]$Owner)
$ErrorActionPreference='Stop'
$taskToken=[Environment]::GetEnvironmentVariable('GH_TOKEN')
if(-not $taskToken){throw '请通过 GitHub 集成登录或使用临时 GH_TOKEN；不在项目文件中保存凭据'}
$taskHeaders=@{Authorization=('Bearer '+$taskToken);Accept='application/vnd.github+json';'X-GitHub-Api-Version'='2022-11-28';'User-Agent'='Hhub-Plugin-Library'}
$taskUser=Invoke-RestMethod -Uri 'https://api.github.com/user' -Headers $taskHeaders
if($taskUser.login -ne $Owner){throw '仓库所有者与登录账号不一致'}
$taskRepoUrl='https://api.github.com/repos/'+$Owner+'/H-hub-plugins'
try{$taskRepo=Invoke-RestMethod -Uri $taskRepoUrl -Headers $taskHeaders}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw};$taskBody=@{name='H-hub-plugins';description='H hub插件库';private=$false;auto_init=$true}|ConvertTo-Json;$taskRepo=Invoke-RestMethod -Method Post -Uri 'https://api.github.com/user/repos' -Headers $taskHeaders -Body $taskBody -ContentType 'application/json'}
& (Join-Path $PSScriptRoot 'build-index.ps1') -Repository ($Owner+'/H-hub-plugins')
foreach($taskFile in Get-ChildItem -LiteralPath $PSScriptRoot -File|Where-Object{$_.Name -eq 'README.md' -or $_.Name -eq 'index.json' -or $_.Extension -eq '.hhub'}){
 $taskUrl=$taskRepoUrl+'/contents/'+[Uri]::EscapeDataString($taskFile.Name)
 $taskBody=@{message=('Publish '+$taskFile.Name);content=[Convert]::ToBase64String([IO.File]::ReadAllBytes($taskFile.FullName));branch=$taskRepo.default_branch}
 try{$taskExisting=Invoke-RestMethod -Uri $taskUrl -Headers $taskHeaders;$taskBody.sha=$taskExisting.sha}catch{if($_.Exception.Response.StatusCode.value__ -ne 404){throw}}
 Invoke-RestMethod -Method Put -Uri $taskUrl -Headers $taskHeaders -Body ($taskBody|ConvertTo-Json) -ContentType 'application/json' | Out-Null
}
Write-Output $taskRepo.html_url
