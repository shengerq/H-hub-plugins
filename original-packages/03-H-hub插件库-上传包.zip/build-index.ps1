﻿param([string]$Repository='')
$ErrorActionPreference='Stop'
$taskRoot=[IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$taskEntries=@()
foreach($taskItem in @(@{file='dist\plugins\Hhub-Rapoo-VT3S-MAX-0.5.1.hhub';kind='mouse';description='雷柏 VT3S MAX：七档 DPI、改键、参数自动同步及电量上报。固件刷写尚未开放。';tags=@('鼠标','雷柏','VT3S MAX')},@{file='dist\developer-tools\Hhub-Developer-Tools-0.5.1.hhub';kind='developer-tools';description='鼠标、键盘、音频及手柄插件开发工作台，独立安装。';tags=@('开发者','插件开发','外设')})){
 $taskSource=Join-Path $taskRoot $taskItem.file
 $taskManifest=Get-Content -LiteralPath $taskSource -Raw -Encoding UTF8|ConvertFrom-Json
 $taskName=[IO.Path]::GetFileName($taskSource)
 Copy-Item -LiteralPath $taskSource -Destination (Join-Path $PSScriptRoot $taskName) -Force
 $taskEntries+=@{id=$taskManifest.id;name=$taskManifest.name;author=$taskManifest.author;version=$taskManifest.version;description=$taskItem.description;kind=$taskItem.kind;tags=$taskItem.tags;packageUrl=$taskName;sha256=(Get-FileHash -LiteralPath $taskSource -Algorithm SHA256).Hash.ToLowerInvariant()}
}
$taskIndex=@{schemaVersion=1;name='H hub插件库';plugins=$taskEntries}
$taskJson=$taskIndex|ConvertTo-Json -Depth 12
[IO.File]::WriteAllText((Join-Path $PSScriptRoot 'index.json'),$taskJson,(New-Object Text.UTF8Encoding($false)))
$taskCache=$taskIndex.Clone();$taskCache.indexUrl=''
[IO.File]::WriteAllText((Join-Path $taskRoot 'app\plugin-library-cache.json'),($taskCache|ConvertTo-Json -Depth 12),(New-Object Text.UTF8Encoding($false)))
$taskConfig=@{name='H hub插件库';repository=$Repository;indexUrl=if($Repository){'https://raw.githubusercontent.com/'+$Repository+'/main/index.json'}else{''}}
[IO.File]::WriteAllText((Join-Path $taskRoot 'app\plugin-library-source.json'),($taskConfig|ConvertTo-Json),(New-Object Text.UTF8Encoding($false)))
Write-Output ('Generated '+$taskEntries.Count+' plugin entries')
